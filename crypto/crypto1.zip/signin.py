from secret import flag
from Crypto.Util.number import bytes_to_long

m = bytes_to_long(flag)
print(m)

# 2191791638908840156765536270892615890049122589128917876054775676626045